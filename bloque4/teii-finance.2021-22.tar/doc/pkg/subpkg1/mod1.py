a = 'foo'

def foo():
    print('[pkg.subpkg1.mod1] foo()')