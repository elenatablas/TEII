_b = 'bar'

def bar():
    print('[pkg.subpkg1.mod2] bar()')