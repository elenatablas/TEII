c = 'baz'

def baz():
    print('[pkg.subpkg2.mod3] baz()')