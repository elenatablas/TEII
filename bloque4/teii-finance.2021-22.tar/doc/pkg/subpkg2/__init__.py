from .mod3 import baz

__all__ = ['baz']

print("Running pkg.subpkg2.__init__.py")