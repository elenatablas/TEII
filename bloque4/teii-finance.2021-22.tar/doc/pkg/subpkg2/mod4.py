__all__ = ['_d']

_d = 'qux'

def qux():
    print('[pkg.subpkg2.mod4] qux()')